#!/bin/bash
set -e
rm -rf ca/
rm -rf certs/
rm -rf crl/
rm -f ./*.jks
rm -f ./*.pem
rm -f ./*.p12
rm -f ./*.csr
rm -f ./*.key*
rm -f ./*tmp*
